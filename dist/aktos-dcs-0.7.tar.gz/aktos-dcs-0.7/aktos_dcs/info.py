__author__ = 'ceremcem'
#import gevent
#import color
#print color.warning("warning: ")
#print color.warning("warning: You SHOULD define App specific messages ")
#print color.warning("warning: in AppMessages module in your path")
#print color.warning("warning: ")
#gevent.sleep(5)
